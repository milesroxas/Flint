import{r as e}from"../bundle.js";function t(){e()}export{t as resetStyleServiceCache};
